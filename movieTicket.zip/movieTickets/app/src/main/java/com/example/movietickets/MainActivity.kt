
package com.example.movietickets
import android.animation.Animator
import android.animation.AnimatorInflater
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.app.DatePickerDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.*
import android.widget.ImageView
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {
    private lateinit var ticketSeekBar: SeekBar
    private lateinit var ticketCountText: TextView
    private lateinit var totalPriceText: TextView
    private lateinit var dateButton: Button
    private lateinit var getTicketsButton: Button
    private lateinit var moviePoster: ImageView
    private lateinit var bottomImage: ImageView
    private lateinit var movieTitle: TextView
    private lateinit var movieDescription: TextView
    private lateinit var adultToggle: RadioButton
    private lateinit var childToggle: RadioButton
    private lateinit var theatreSpinner: Spinner
    private lateinit var exitBtn : Button

    private val images = intArrayOf(R.drawable.john_2,R.drawable.john_1,R.drawable.john_3)
    private var currentImageIndex = 0
    private val adultPRICE = 15.0
    private val childPRICE = 10.0
    private var selectedDate: Calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main))
        { v, insets -> val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initializeViews()
        setupListeners()
        posterAnimation()
        imageSwitchAnimation()
    }

    private fun initializeViews() {
        ticketSeekBar = findViewById(R.id.ticketSeekBar)
        ticketCountText = findViewById(R.id.ticketCountText)
        totalPriceText = findViewById(R.id.totalPriceText)
        dateButton = findViewById(R.id.dateButton)
        getTicketsButton = findViewById(R.id.getTicketsButton)
        moviePoster = findViewById(R.id.moviePoster)
        movieTitle = findViewById(R.id.movieTitle)
        movieDescription = findViewById(R.id.movieDescription)
        adultToggle = findViewById(R.id.adultRadio)
        childToggle = findViewById(R.id.childRadio)
        theatreSpinner = findViewById(R.id.theatreSpinner)
        bottomImage=findViewById(R.id. bottomImage)
        exitBtn = findViewById(R.id.exitButton)
        // Set up the spinner for theatres
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, resources.getStringArray(R.array.theatres)) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent) as TextView
                view.setTextColor(ContextCompat.getColor(context, android.R.color.white))
                return view }}
        theatreSpinner.adapter = adapter
    }

    private fun setupListeners() {

        ticketSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateTicketInfo(progress)
            }override fun onStartTrackingTouch(seekBar: SeekBar?){}override fun onStopTrackingTouch(seekBar: SeekBar?){}})
        // Listeners for the  radio button change
        adultToggle.setOnCheckedChangeListener { _, _ -> updateTicketInfo(ticketSeekBar.progress) }
        childToggle.setOnCheckedChangeListener { _, _ -> updateTicketInfo(ticketSeekBar.progress) }

        dateButton.setOnClickListener{button->
            scaleAnimationBtn(button)
            showDatePicker()
           bottomAnimation()
        }

        getTicketsButton.setOnClickListener{ button->
            scaleAnimationBtn(button)
            // Validation checks
            if (ticketSeekBar.progress == 0) {
                // Show an alert dialog if no tickets are selected
                MaterialAlertDialogBuilder(this)
                    .setTitle(getString(R.string.no_tickets_title))
                    .setMessage(getString(R.string.no_tickets_message))
                    .setPositiveButton(getString(R.string.ok)) { dialog, _ -> dialog.dismiss() }
                    .create()
                    .show()
                return@setOnClickListener
            }
            // Validate date selection
            if (dateButton.text.toString() == getString(R.string.select_date)) {
                MaterialAlertDialogBuilder(this)
                    .setTitle(getString(R.string.no_date_title))
                    .setMessage(getString(R.string.no_date_message))
                    .setPositiveButton(getString(R.string.ok)) { dialog, _ -> dialog.dismiss() }
                    .create()
                    .show()
                return@setOnClickListener
            }
        // If all validations pass, proceed to show ticket summary
            showTicketSummary()
            bottomAnimation()
        }

        exitBtn.setOnClickListener { button ->
            scaleAnimationBtn(button)
            val builder = AlertDialog.Builder(this)
            builder.setTitle(getString(R.string.Exit))
                .setMessage(getString(R.string.dialog_text))
                .setCancelable(false)
                .setIcon(R.drawable.baseline_exit_to_app_24)
                .setPositiveButton(R.string.yes) { _, _ -> finish() }
                .setNegativeButton(R.string.no) { dialog, _ -> dialog.dismiss() }
                .create()
                .show()
        }

    }


   private fun imageSwitchAnimation() {
    moviePoster.setImageResource(images[currentImageIndex])
    val animator = AnimatorInflater.loadAnimator(this, R.animator.image_switcher_animation) as AnimatorSet
    animator.setTarget(moviePoster)
    // Add a listener to switch images
    animator.addListener(object : AnimatorListenerAdapter()
    { override fun onAnimationEnd(animation: Animator) {
            // Switch to the next image
            currentImageIndex = (currentImageIndex + 1) % images.size
            imageSwitchAnimation()
        } })
    animator.start()
    }

    private fun posterAndBottomAnimation() {
        posterAnimation()
        bottomAnimation()
    }
    private fun posterAnimation() {
        val animator1 = AnimatorInflater.loadAnimator(this, R.animator.movie_poster_animation) as AnimatorSet
        animator1.setTarget(moviePoster)
        animator1.start()
    }
    private fun bottomAnimation() {
        val animator2 = AnimatorInflater.loadAnimator(this, R.animator.movie_poster_animation) as AnimatorSet
        animator2.setTarget(bottomImage)
        animator2.start()
    }
    private fun scaleAnimationBtn(button: View)
    { val scaleAnimation = AnimationUtils.loadAnimation(this, R.anim.button_click_animation)
        button.startAnimation(scaleAnimation)
    }



    private fun updateTicketInfo(ticketCount: Int) {
        ticketCountText.text = getString(R.string.ticket_count, ticketCount)
        val price = if (adultToggle.isChecked) adultPRICE else childPRICE
        totalPriceText.text = getString(R.string.total_price, ticketCount * price)
    }

    private fun showDatePicker()
    { DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate.set(year, month, dayOfMonth)
                val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                dateButton.text = dateFormat.format(selectedDate.time)
            },
            selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH), selectedDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTicketSummary()
    {   val customDialog = layoutInflater.inflate(R.layout.ticket_summary_dialog, null)
        val summaryText = customDialog.findViewById<TextView>(R.id.summaryText)
        val confirmButton = customDialog.findViewById<Button>(R.id.confirmButton)
        val ticketType = if (adultToggle.isChecked) getString(R.string.adult) else getString(R.string.child)
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        summaryText.text = getString(
            R.string.summary_text,
            ticketSeekBar.progress, // %1$d: Number of tickets
            ticketType,             // %2$s: Ticket type
            dateFormat.format(selectedDate.time), // %3$s: Formatted date
            theatreSpinner.selectedItem,          // %4$s: Selected theatre
            ticketSeekBar.progress * (if (adultToggle.isChecked) adultPRICE else childPRICE))
        val dialog = AlertDialog.Builder(this).setView(customDialog).setCancelable(true).create()
        confirmButton.setOnClickListener { showOrderConfirmation()
            dialog.dismiss() }
            dialog.show()
    }

    private fun showOrderConfirmation() {
        // Prepare order details
        val ticketType = if (adultToggle.isChecked) getString(R.string.adult) else getString(R.string.child)
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val orderDetails =getString(
            R.string.order_confirm_details,
            ticketSeekBar.progress, // %1$d: Number of tickets
            ticketType,             // %2$s: Ticket type
            dateFormat.format(selectedDate.time), // %3$s: Formatted date
            theatreSpinner.selectedItem,          // %4$s: Selected theatre
            ticketSeekBar.progress * (if (adultToggle.isChecked) adultPRICE else childPRICE))
        //  custom layout with progress indicator
        val dialogView = layoutInflater.inflate(R.layout.dialog_order_processing, null)
        val progressText = dialogView.findViewById<TextView>(R.id.processingText)
        val dialog = MaterialAlertDialogBuilder(this).setTitle(R.string.confirm_purchase).setView(dialogView).setCancelable(false).create()
        dialog.show()
        // Simulate order processing
        Handler(Looper.getMainLooper()).postDelayed({
            progressText.text =
            getString(R.string.checking_seat_availability)
            Handler(Looper.getMainLooper()).postDelayed({ progressText.text = getString(R.string.processing_payment)
                Handler(Looper.getMainLooper()).postDelayed({ dialog.dismiss()
                    // Show final confirmation dialog
                    MaterialAlertDialogBuilder(this)
                        .setTitle(getString(R.string.order_confirmation2)).setMessage(orderDetails + getString(R.string.order_placed_successfully)).setPositiveButton(getString(R.string.ok))
                        { confirmDialog, _ -> resetBookingForm()
                            confirmDialog.dismiss() }.create().show() }, 1000) }, 1000) }, 1000)
        posterAndBottomAnimation()
    }

    private fun resetBookingForm() {
        ticketSeekBar.progress = 0
        updateTicketInfo(0)
        dateButton.text = getString(R.string.select_date)
        selectedDate = Calendar.getInstance()
        theatreSpinner.setSelection(0)
        adultToggle.isChecked = true
    }

}


